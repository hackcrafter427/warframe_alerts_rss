# warframe_alerts_rss

Get Warframe Alerts From http://content.warframe.com/dynamic/rss.php
